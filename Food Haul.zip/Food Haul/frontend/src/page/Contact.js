import "./ContactStyles.css"
import { useRef } from "react";
import emailjs from '@emailjs/browser';
const ContactForm = ()=>{
	const form = useRef()
	const sendEmail = (e) => {
		e.preventDefault();
	
		emailjs.sendForm('service_dn8z1pw', 'template_1t4x37b', form.current, 'I03tadZOj7K-quQLg')
		  .then((result) => {
			  console.log(result.text);
			  alert("Email Sent Successfully");
		  }, (error) => {
			  console.log(error.text);
		  });
		  e.target.reset()
	  };

    return(
        <div className="from-container">
            <h1>Send a message to us !</h1>
            <form ref = {form} onSubmit = {sendEmail}> 
			<input type="text" placeholder="Name" name ='user_name'/>
                <input type="email" placeholder="Email" name='user_email'/>
                <input type="text" placeholder="Subject" name='subject'/>
                <textarea name="message" placeholder="Message" rows ="4"></textarea>
                <button>Send Message</button>
            </form>
        </div>
    )
}

export default ContactForm;